package com.example.examen1bimestre

class RecyclerAdaptador (

    private val listaCanciones:List<Cancion>

){

}