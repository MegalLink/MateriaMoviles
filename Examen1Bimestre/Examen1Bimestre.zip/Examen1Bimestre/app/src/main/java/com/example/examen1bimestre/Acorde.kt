package com.example.examen1bimestre

class Acorde(var notacionInglesa:String, var notacionLatina:String, var imagen: Int) {


}