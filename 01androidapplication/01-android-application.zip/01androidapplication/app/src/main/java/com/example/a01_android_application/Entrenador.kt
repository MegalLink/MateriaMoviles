package com.example.a01_android_application

class Entrenador(var nombre:String,var apellido:String) {
    override fun toString(): String {
        return "Nombre:${nombre} Apellido:${apellido}"
    }
}