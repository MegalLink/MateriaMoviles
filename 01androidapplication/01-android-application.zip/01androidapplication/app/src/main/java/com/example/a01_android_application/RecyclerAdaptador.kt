package com.example.a01_android_application

class RecyclerAdaptador(
    private val listaUsuarios:List<UsuarioHttp>,
/* private val contexto */
    private val reyclerView:RecyclerView) {
 }