package com.example.a01_android_application
class ServicioBDDMemoria{
    companion object{
        var numero=1;
        fun añadirNumero(){
            this.numero=this.numero+1
        }
    }

}
